﻿
namespace Ejercicio196
{
	partial class Form1
	{
		/// <summary>
		/// Variable del diseñador necesaria.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Limpiar los recursos que se estén usando.
		/// </summary>
		/// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Código generado por el Diseñador de Windows Forms

		/// <summary>
		/// Método necesario para admitir el Diseñador. No se puede modificar
		/// el contenido de este método con el editor de código.
		/// </summary>
		private void InitializeComponent()
		{
			this.btDividir = new System.Windows.Forms.Button();
			this.btMultiplicar = new System.Windows.Forms.Button();
			this.btResta = new System.Windows.Forms.Button();
			this.btSuma = new System.Windows.Forms.Button();
			this.tbNum1 = new System.Windows.Forms.TextBox();
			this.tbResultado = new System.Windows.Forms.TextBox();
			this.tbNum2 = new System.Windows.Forms.TextBox();
			this.lbResultados = new System.Windows.Forms.ListBox();
			this.SuspendLayout();
			// 
			// btDividir
			// 
			this.btDividir.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btDividir.Location = new System.Drawing.Point(120, 159);
			this.btDividir.Name = "btDividir";
			this.btDividir.Size = new System.Drawing.Size(30, 30);
			this.btDividir.TabIndex = 0;
			this.btDividir.Text = "/";
			this.btDividir.UseVisualStyleBackColor = true;
			this.btDividir.Click += new System.EventHandler(this.btDividir_Click);
			// 
			// btMultiplicar
			// 
			this.btMultiplicar.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btMultiplicar.Location = new System.Drawing.Point(50, 159);
			this.btMultiplicar.Name = "btMultiplicar";
			this.btMultiplicar.Size = new System.Drawing.Size(30, 30);
			this.btMultiplicar.TabIndex = 1;
			this.btMultiplicar.Text = "x";
			this.btMultiplicar.UseVisualStyleBackColor = true;
			this.btMultiplicar.Click += new System.EventHandler(this.btMultiplicar_Click);
			// 
			// btResta
			// 
			this.btResta.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btResta.Location = new System.Drawing.Point(120, 103);
			this.btResta.Name = "btResta";
			this.btResta.Size = new System.Drawing.Size(30, 30);
			this.btResta.TabIndex = 2;
			this.btResta.Text = "-";
			this.btResta.UseVisualStyleBackColor = true;
			this.btResta.Click += new System.EventHandler(this.btResta_Click);
			// 
			// btSuma
			// 
			this.btSuma.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.btSuma.Location = new System.Drawing.Point(50, 103);
			this.btSuma.Name = "btSuma";
			this.btSuma.Size = new System.Drawing.Size(30, 30);
			this.btSuma.TabIndex = 3;
			this.btSuma.Text = "+";
			this.btSuma.UseVisualStyleBackColor = true;
			this.btSuma.Click += new System.EventHandler(this.btSuma_Click);
			// 
			// tbNum1
			// 
			this.tbNum1.Location = new System.Drawing.Point(50, 51);
			this.tbNum1.Name = "tbNum1";
			this.tbNum1.Size = new System.Drawing.Size(100, 20);
			this.tbNum1.TabIndex = 4;
			// 
			// tbResultado
			// 
			this.tbResultado.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.tbResultado.Location = new System.Drawing.Point(32, 285);
			this.tbResultado.Name = "tbResultado";
			this.tbResultado.ReadOnly = true;
			this.tbResultado.Size = new System.Drawing.Size(144, 20);
			this.tbResultado.TabIndex = 6;
			this.tbResultado.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
			this.tbResultado.TextChanged += new System.EventHandler(this.tbResultado_TextChanged);
			// 
			// tbNum2
			// 
			this.tbNum2.Location = new System.Drawing.Point(50, 230);
			this.tbNum2.Name = "tbNum2";
			this.tbNum2.Size = new System.Drawing.Size(100, 20);
			this.tbNum2.TabIndex = 7;
			// 
			// lbResultados
			// 
			this.lbResultados.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.lbResultados.FormattingEnabled = true;
			this.lbResultados.Location = new System.Drawing.Point(231, 41);
			this.lbResultados.Name = "lbResultados";
			this.lbResultados.Size = new System.Drawing.Size(244, 225);
			this.lbResultados.TabIndex = 8;
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(507, 378);
			this.Controls.Add(this.lbResultados);
			this.Controls.Add(this.tbNum2);
			this.Controls.Add(this.tbResultado);
			this.Controls.Add(this.tbNum1);
			this.Controls.Add(this.btSuma);
			this.Controls.Add(this.btResta);
			this.Controls.Add(this.btMultiplicar);
			this.Controls.Add(this.btDividir);
			this.Name = "Form1";
			this.Text = "Calculadora";
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button btDividir;
		private System.Windows.Forms.Button btMultiplicar;
		private System.Windows.Forms.Button btResta;
		private System.Windows.Forms.Button btSuma;
		private System.Windows.Forms.TextBox tbNum1;
		private System.Windows.Forms.TextBox tbResultado;
		private System.Windows.Forms.TextBox tbNum2;
		private System.Windows.Forms.ListBox lbResultados;
	}
}

