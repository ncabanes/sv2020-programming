﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;

using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio196
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void btSuma_Click(object sender, EventArgs e)
		{
			try
			{
				int num1 = Convert.ToInt32(tbNum1.Text);
				int num2 = Convert.ToInt32(tbNum2.Text);
				int resultado = num1 + num2;

				tbResultado.Text = num1 + " + " +  num2 + " = " + 
					Convert.ToString(resultado);

			}
			catch (Exception)
			{
				MessageBox.Show("Hay un numero no valido", "Error", 
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}		
		}

		private void btResta_Click(object sender, EventArgs e)
		{
			try
			{
				int num1 = Convert.ToInt32(tbNum1.Text);
				int num2 = Convert.ToInt32(tbNum2.Text);
				int resultado = num1 - num2;

				tbResultado.Text = num1 + " - " + num2 + " = " +
					Convert.ToString(resultado);

			}
			catch (Exception)
			{
				MessageBox.Show("Hay un numero no valido", "Error",
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void btMultiplicar_Click(object sender, EventArgs e)
		{
			try
			{
				int num1 = Convert.ToInt32(tbNum1.Text);
				int num2 = Convert.ToInt32(tbNum2.Text);
				int resultado = num1 * num2;

				tbResultado.Text = num1 + " x " + num2 + " = " +
					Convert.ToString(resultado);

			}
			catch (Exception)
			{
				MessageBox.Show("Hay un numero no valido", "Error",
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void btDividir_Click(object sender, EventArgs e)
		{
			try
			{
				double num1 = Convert.ToDouble(tbNum1.Text);
				double num2 = Convert.ToDouble(tbNum2.Text);
				double resultado = num1 / num2;

				tbResultado.Text = num1 + " / " + num2 + " = " +
					resultado.ToString("N8");

			}
			catch (Exception)
			{
				MessageBox.Show("Hay un numero no valido", "Error",
					MessageBoxButtons.OK, MessageBoxIcon.Error);
			}
		}

		private void tbResultado_TextChanged(object sender, EventArgs e)
		{
			lbResultados.Items.Add(tbResultado.Text);
		}
	}
}
