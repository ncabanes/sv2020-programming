﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;

/*200. Debes crear una aplicación para anotar tareas pendientes, que permita:
1. Añadir una nueva tarea pendiente (id, descripción y prioridad).
2. Mostrar todas las tareas pendientes, ordenadas por prioridad descendente.
3. Modificar una tarea, a partir de su id.
4. Marcar una tarea como completada, a partir de su id (no se borrará realmente
, sino que se marcará como completada y no
se mostrará en la opción 2).
0. Salir
Los datos deben estar almacenados en una base de datos creada con SQLite.*/

//Iván Fernández Pastor 

class TareasSQLite
{
    static SQLiteConnection conexion;
    string[] urgencia = new string[3];

    public TareasSQLite()
    {
        urgencia[0] = "(1)BAJA";
        urgencia[1] = "(2)MEDIA";
        urgencia[2] = "(3)ALTA";

        ConexionBD();
    }

    private void ConexionBD()
    {
        if (!File.Exists("ejercicio200.sqlite"))
        {
            conexion = new SQLiteConnection(
                "Data Source=ejercicio200.sqlite;Version=3;New=True;Compress=True;");
            conexion.Open();

            string crearTabla = "CREATE TABLE tareas( id INTEGER primary key "
                + "AUTOINCREMENT, descripcion varchar(100), "
                + "prioridad varchar(20), completada NUMBER(1));";

            SQLiteCommand cmd = new SQLiteCommand(crearTabla, conexion);
            cmd.ExecuteNonQuery();
        }
        else
        {
            conexion = new SQLiteConnection(
                "Data Source=ejercicio200.sqlite;Version=3;New=True;Compress=True;");
            conexion.Open();
        }
    }

    public bool Anyadir()
    {
        Console.Clear();
        string insercion; 
        SQLiteCommand cmd;
        int cantidad;
        string prioridad = "";

        Console.WriteLine("NUEVA TAREA");
        Console.Write("Descripción: ");
        string descripcion = Console.ReadLine();
        Console.Write("Prioridad (1 - BAJA / 2 - MEDIA / 3 - ALTA): ");
        int idprioridad = Convert.ToInt32(Console.ReadLine());

        if (idprioridad == 1)
            prioridad = urgencia[0];
        if (idprioridad == 2)
            prioridad = urgencia[1];
        if (idprioridad == 3)
            prioridad = urgencia[2];

        try
        {
            insercion = "INSERT INTO tareas (descripcion, prioridad, completada) " +
              "VALUES  ('" + descripcion + "','" + prioridad + "'," + 0 + ");";
            cmd = new SQLiteCommand(insercion, conexion);
            cantidad = cmd.ExecuteNonQuery();
            if (cantidad < 1)
                return false;
        }
        catch (Exception)
        {
            return false;
        }
        Console.WriteLine();
        return true;
    }

    public void MostrarTodos()
    {
        Console.Clear();
        List<string> resultado = new List<string>();
        string consulta = "select * from tareas where completada=0 order by " +
            "prioridad DESC";
        SQLiteCommand cmd = new SQLiteCommand(consulta, conexion);
        SQLiteDataReader datos = cmd.ExecuteReader();
        
        while (datos.Read())
        {
            resultado.Add(datos[0] + " - " + datos[1] + " - "
                + datos[2]);
        }

        Console.WriteLine("LISTADO DE TAREAS PENDIENTES");
        foreach (string dato in resultado)
            Console.WriteLine(dato);

        Console.WriteLine();
    }

    public void ModificarDatos()
    {
        Console.Clear();
        string actualizar;
        SQLiteCommand cmd;
        int cantidad;

        Console.Write("ID de tarea a modificar: ");
        int idtarea = Convert.ToInt32(Console.ReadLine());
        Console.Write("Nueva descripción: ");
        string nuevaDescripcion = Console.ReadLine();

        actualizar = "UPDATE tareas SET descripcion ='" + nuevaDescripcion +
            "' WHERE id='" + idtarea + "';";
        cmd = new SQLiteCommand(actualizar, conexion);
        cantidad = cmd.ExecuteNonQuery();
        if (cantidad > 0)
            Console.WriteLine("Datos actualizados correctamente");
        else
            Console.WriteLine("ERROR: Compruebe el ID de la tarea");
    }

    public void MarcarCompletada()
    {
        Console.Clear();
        string actualizar;
        SQLiteCommand cmd;
        int cantidad;

        Console.Write("ID de tarea a completar: ");
        int id = Convert.ToInt32(Console.ReadLine());
  
        actualizar = "UPDATE tareas " +
            "SET completada = 1 WHERE id='" + id + "';";
        cmd = new SQLiteCommand(actualizar, conexion);
        cantidad = cmd.ExecuteNonQuery();
        if (cantidad > 0)
            Console.WriteLine("Tarea completada correctamente");
        else
            Console.WriteLine("ERROR: Compruebe el ID de la tarea");
    }

    public void Menu()
    {
        Console.WriteLine("1.- Añadir tarea pendiente");
        Console.WriteLine("2.- Mostrar tareas pendientes");
        Console.WriteLine("3.- Modificar tarea");
        Console.WriteLine("4.- Marcar tarea como completada");
        Console.WriteLine("0.- Salir");
        Console.WriteLine();
        Console.Write("Seleccione una opción: ");
    }

    public void Ejectutar()
    {
        string opcion;
        do
        {
            Menu();
            opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    Anyadir();
                    break;
                case "2":
                    MostrarTodos();
                    break;
                case "3":
                    ModificarDatos();
                    break;
                case "4":
                    MarcarCompletada();
                    break;
            }
        } while (opcion != "0");
        Console.WriteLine("Hasta luego");
    }
}

class ListaDeTareas
{
    static void Main()
    {
        TareasSQLite t = new TareasSQLite();
        t.Ejectutar();
    }     
}
