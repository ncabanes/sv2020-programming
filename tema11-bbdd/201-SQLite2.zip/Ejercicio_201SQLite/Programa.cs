﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Data.SQLite;

/*201. Crea una nueva versión del gestor de programas V3 (en clases y con lista
 * , ej.171b), partiendo de la versión oficial, en la que guardes datos 
 * empleando SQLite.*/

//Iván Fernández Pastor 

class GestorDeProgramasSQLite
{
    static SQLiteConnection conexion;

    public GestorDeProgramasSQLite()
    {
        ConexionBD();
    }

    private void ConexionBD()
    {
        if (!File.Exists("ejercicio201.sqlite"))
        {
            conexion = new SQLiteConnection(
                "Data Source=ejercicio201.sqlite;Version=3;New=True;Compress=True;");
            conexion.Open();

            string crearTabla = "CREATE TABLE programa( nombre varchar(25) "
                + "primary key, descripcion varchar(100), "
                + "mesLanzamiento NUMBER(2), anyoLanzamiento NUMBER(4), "
                + "precio NUMBER(8,2), comercial NUMBER(1));";

            SQLiteCommand cmd = new SQLiteCommand(crearTabla, conexion);
            cmd.ExecuteNonQuery();
        }
        else
        {
            conexion = new SQLiteConnection(
                "Data Source=ejercicio201.sqlite;Version=3;New=True;Compress=True;");
            conexion.Open();
        }
    }

    private void MostrarMenu()
    {
        Console.Clear();
        Console.WriteLine("1. Ver datos de todos los programas");
        Console.WriteLine("2. Buscar texto");
        Console.WriteLine("3. Añadir un programa");
        Console.WriteLine("0. Salir");
    }

    private static string Pedir(string aviso)
    {
        Console.Write(aviso + ": ");
        string respuesta = Console.ReadLine();

        return respuesta;
    }

    public bool Anyadir(string nombre, string descripcion, int mes, int anyo)
    {
        string insercion;  
        SQLiteCommand cmd;
        int cantidad;

        try
        {
            insercion = "INSERT INTO programa " +
              "VALUES  ('" + nombre + "','" + descripcion + "'," + mes +
                ",'" + anyo + "', 0, 0);";
            cmd = new SQLiteCommand(insercion, conexion);
            cantidad = cmd.ExecuteNonQuery();
            if (cantidad < 1)
                return false;
        }
        catch (Exception)
        {
            return false;
        }
        return true;
    }

    public List<string> VerTodos()
    {
        List<string> resultado = new List<string>();
        string consulta = "select * from programa";
        SQLiteCommand cmd = new SQLiteCommand(consulta, conexion);
        SQLiteDataReader datos = cmd.ExecuteReader();
       
        while (datos.Read())
        {
            resultado.Add(datos[0] + " - " + datos[1] + " - "
                + Convert.ToInt32(datos[2]) + " - "
                + Convert.ToString(datos[3]));
        }
        return resultado;
    }

    public List<string> BuscarTexto(string texto)
    {
        List<string> resultado = new List<string>();
        string consulta = "select * from programa where nombre like '%"
            + texto + "%' or descripcion like '%" + texto + "%';";
        SQLiteCommand cmd = new SQLiteCommand(consulta, conexion);
        SQLiteDataReader datos = cmd.ExecuteReader();
        
        while (datos.Read())
        {
            resultado.Add(datos[0] + " - " + datos[1] + " - "
                + Convert.ToInt32(datos[2]) + " - "
                + Convert.ToString(datos[3]));
        }
        return resultado;
    }

    public void Run()
    {
        string opcion;
        bool salir = false;
        GestorDeProgramasSQLite coleccion = new GestorDeProgramasSQLite();

        do
        {
            MostrarMenu();
            opcion = Console.ReadLine();

            switch (opcion)
            {
                case "1":
                    foreach (string dato in coleccion.VerTodos())
                        Console.WriteLine(dato);
                    break;
                case "2":
                    string txt = Pedir("Introduce el texto a buscar:");
                    foreach (string dato in coleccion.BuscarTexto(txt))
                        Console.WriteLine(dato);
                    break;
                case "3":
                    string nombre = Pedir("Nombre");
                    string descripcion = Pedir("Descripción");
                    int mes = Convert.ToInt32(Pedir("Mes de lanzamiento"));
                    int anyo = Convert.ToInt32(Pedir("Año de publicación"));
                    coleccion.Anyadir(nombre, descripcion, mes, anyo);
                    break;
                case "0": salir = true; break;
                default: Console.WriteLine("Opción incorrecta"); break;
            }

            if (!salir)
            {
                Console.WriteLine();
                Console.WriteLine("Intro para continuar...");
                Console.ReadLine();
            }

        } while (!salir);

        Console.WriteLine("Hasta luego");
    }
}

//-----------------------------------

class PruebaPrograma
{
    static void Main()
    {
        GestorDeProgramasSQLite gestor = new GestorDeProgramasSQLite();
        gestor.Run();
    }
}
