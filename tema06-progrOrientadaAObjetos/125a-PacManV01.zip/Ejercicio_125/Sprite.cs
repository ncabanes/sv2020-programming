﻿using System;

class Sprite
{
    protected int x, y;
    protected char caracter;

    public Sprite()
    {
        x = GetX();
        y = GetY();
        caracter = GetCaracter();
    }

    public int GetX() { return x; }

    public int GetY() { return y; }

    public char GetCaracter() { return caracter; }

    public void SetX(int nuevaX)
    {
        x = nuevaX;
    }

    public void SetY(int nuevaY)
    {
        y = nuevaY;
    }

    public void SetCaracter(char nuevoCaracter)
    {
        caracter = nuevoCaracter;
    }

    public void Mostrar()
    {
        Console.SetCursorPosition(x, y);
        Console.WriteLine(caracter);
    }
}
