﻿class FantasmaAzul : Fantasma
{
    public FantasmaAzul() : this(35, 35)
    {
    }

    public FantasmaAzul(int X, int Y) : base(X, Y)
    {
        this.X = X;
        this.Y = Y;
        caracter = 'A';
    }

    public override void MoverArriba()
    {
        Y--;
    }

    public override void MoverAbajo()
    {
        Y++;
    }

    public override void MoverIzquierda()
    {
        X--;
    }

    public override void MoverDerecha()
    {
        X++;
    }
}