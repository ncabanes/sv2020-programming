﻿using System;

abstract class Sprite
{

    public int X { get; set; }
    public int Y { get; set; }

    public char caracter { get; set; }

    public virtual void Mover()
    {

    }

    public virtual void MoverArriba()
    {

    }

    public virtual void MoverAbajo()
    {

    }

    public virtual void MoverIzquierda()
    {

    }

    public virtual void MoverDerecha()
    {

    }

    public void Mostrar()
    {
        Console.SetCursorPosition(X, Y);
        Console.Write(caracter);
        Console.SetCursorPosition(0, 0);
    }
}