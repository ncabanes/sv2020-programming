﻿using System;

/*158. Crea una nueva versión de PacMan (ejercicio 149), partiendo de la 
 * solución oficial, con los siguientes cambios:

- Debe existir una clase "Nivel", que represente un nivel del juego (con su 
laberinto y sus píldoras de 2 tamaños). Tendrá un método Mostrar(), que dibuje
el nivel en pantalla, así como un método bool EsPosibleMoverA(x, y), que 
permitirá saber si tanto Pac como los fantasmas pueden moverse a una cierta 
casilla o no, y como un método int ObtenerPuntosDe(x, y), que permitirá saber 
qué puntos se obtendrán en cierta posición del laberinto cuando Pac se 
desplace a ella (y eliminará la píldora correspondiente).

- No es necesario que el movimiento de los fantasmas recuerde al original, ni 
que gestiones los cambios de estado de los fantasmas, ni ningún otro detalle 
más avanzado.

- Pac sólo podrá moverse a posiciones factibles.

- Habrá un marcador que muestre los puntos obtenidos.

- La partida terminará si se recogen todas las píldoras o si algún fantasma 
alcanza a Pac.*/

//Iván (...)

/*Me he picado mucho con este ejercicio, seguramente
 * no sea la forma más adecuada de plantear un laberinto, pero me he divertido
 * bastante */

class PruebaPacMan
{
    static void Main()
    {
        bool salir = false;
        Nivel n = new Nivel();
        n.CrearLaberinto();
        n.Mostrar();
        n.MostrarMarcador();

        Pac p = new Pac(7, 5);
        p.Mostrar();
        p.Mover();
        Fantasma[] fantasmas = new Fantasma[4];
        fantasmas[0] = new FantasmaRojo(2, 1);
        fantasmas[1] = new FantasmaNaranja(10, 8);
        fantasmas[2] = new FantasmaRosa(11, 1);
        fantasmas[3] = new FantasmaAzul(13, 7);
        do
        {
            n.Mostrar();
            n.MostrarMarcador();
            p.Mostrar();

            for (int i = 0; i < fantasmas.Length; i++)
            {
                fantasmas[i].Mostrar();
            }

            ConsoleKeyInfo tecla = Console.ReadKey();

            switch (tecla.Key)
            {
                case ConsoleKey.Escape:
                    salir = true;
                    break;
                case ConsoleKey.LeftArrow:
                    if(n.EsPosibleMoverA(p.X-1, p.Y))
                        p.X--;
                    n.ObtenerPuntosDe(p.X, p.Y);
                     break;
                case ConsoleKey.RightArrow:
                    if (n.EsPosibleMoverA(p.X+1, p.Y))
                        p.X++;
                    n.ObtenerPuntosDe(p.X, p.Y);
                    break;
                case ConsoleKey.UpArrow:
                    if (n.EsPosibleMoverA(p.X, p.Y-1))
                        p.Y--;
                    n.ObtenerPuntosDe(p.X, p.Y);
                    break;
                case ConsoleKey.DownArrow:
                    if (n.EsPosibleMoverA(p.X, p.Y+1))
                        p.Y++;
                    n.ObtenerPuntosDe(p.X, p.Y);
                    break;
                default:
                    break;
            }

            for (int i = 0; i < fantasmas.Length; i++)
            {//Falta depurar movimiento de fantasmas
                if (n.EsPosibleMoverA(fantasmas[i].X, fantasmas[i].Y + 1))
                    fantasmas[i].MoverAbajo();
                else if (n.EsPosibleMoverA(fantasmas[i].X, fantasmas[i].Y - 1))
                    fantasmas[i].MoverArriba();
                else if (n.EsPosibleMoverA(fantasmas[i].X + 1, fantasmas[i].Y))
                    fantasmas[i].MoverIzquierda();
                else if (n.EsPosibleMoverA(fantasmas[i].X - 1, fantasmas[i].Y))
                    fantasmas[i].MoverDerecha();
            }
            Console.Clear();

            foreach (Fantasma f in fantasmas)
                f.Mostrar();

            n.Mostrar();
            p.Mostrar();

            for (int i = 0; i < fantasmas.Length; i++)
            {
                if (p.X == fantasmas[i].X && p.Y == fantasmas[i].Y)
                    salir = true;
            }

            if (salir)
                
                Console.WriteLine("TE HA COMIDO EL FANTASMA!");

        }
        while (!salir);
        Console.SetCursorPosition(5, 12);
        Console.WriteLine("FIN DE LA PARTIDA!");
    }
}
