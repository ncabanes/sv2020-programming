﻿class FantasmaNaranja : Fantasma
{
    public FantasmaNaranja(int X, int Y) : base(X, Y)
    {
        this.X = X;
        this.Y = Y;
        caracter = 'A';
    }

    public FantasmaNaranja() : this(25, 25)
    {
    }

    public override void MoverArriba()
    {
        Y--;
    }

    public override void MoverAbajo()
    {
        Y++;
    }

    public override void MoverIzquierda()
    {
        X--;
    }

    public override void MoverDerecha()
    {
        X++;
    }
}