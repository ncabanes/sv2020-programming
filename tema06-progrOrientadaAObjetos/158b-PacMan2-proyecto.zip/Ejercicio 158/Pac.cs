﻿class Pac : Sprite
{
    public Pac(int X, int Y)
    {
        this.X = X;
        this.Y = Y;
        caracter = 'C';
    }

    public override void Mover()
    {
    }
}