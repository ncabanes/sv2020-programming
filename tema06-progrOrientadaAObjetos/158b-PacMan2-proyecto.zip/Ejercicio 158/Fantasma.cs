﻿class Fantasma : Sprite
{
    //public Fantasma() { }
    public Fantasma(int X, int Y)
    {
        this.X = X;
        this.Y = Y;
        caracter = 'A';
    }
}