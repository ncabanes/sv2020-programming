﻿class FantasmaRosa : Fantasma
{
    public FantasmaRosa(int X, int Y) : base(X, Y)
    {
        this.X = X;
        this.Y = Y;
        caracter = 'A';
    }

    public FantasmaRosa() : this(30, 30)
    {
    }

    public override void MoverArriba()
    {
        Y--;
    }

    public override void MoverAbajo()
    {
        Y++;
    }

    public override void MoverIzquierda()
    {
        X--;
    }

    public override void MoverDerecha()
    {
        X++;
    }
}