﻿class Fantasma: Sprite
{
    public void Perseguir()
    {

    }

    public void Atrapar()
    {

    }

    public void Desaparecer()
    {

    }
}
