﻿class Bola: Sprite
{
    public void Desaparecer()
    {

    }
}