﻿class Sprite
{
    int x;
    int y;
    string imagen;

    public void Dibujar()
    {

    }

    public void Mover()
    {

    }
}