﻿class Pildora_Magica: Sprite
{
    public void Desaparecer()
    {

    }
}