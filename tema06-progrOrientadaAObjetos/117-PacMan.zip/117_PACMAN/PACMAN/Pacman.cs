﻿class Pacman: Sprite
{
    public void Comer()
    {

    }
    
    public void Atrapar()
    {

    }
}
