﻿class Laberinto
{
    public void Dibujar()
    {

    }
}
