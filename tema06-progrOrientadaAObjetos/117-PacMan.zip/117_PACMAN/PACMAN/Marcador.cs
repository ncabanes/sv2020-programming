﻿class Marcador
{
    public void Mostrar()
    {

    }
}
