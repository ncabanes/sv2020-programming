﻿class Partida
{
    static void Main()
    {
        Laberinto l = new Laberinto();
        Marcador m = new Marcador();

        l.Dibujar();
        m.Mostrar();
    }
}
